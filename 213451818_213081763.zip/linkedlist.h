#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct Var
{
    char *key;
    char *value;
} Var;

typedef struct Node
{
  Var* data;
  struct Node *next;
  struct Node *prev;
} Node;

typedef struct List
{
  int size;
  struct Node *head;
  struct Node *tail;
} List;



void add(List *, void *);
void sort(List *);
void printList(List *);
void *get_command(List *, int);