#include "linkedlist.h"

void *get_command(List *ll, int index)
{
	if (!ll) 
	{
		return NULL;
	}
	if(ll->size == 0)
	{
		return NULL;
	}
	int i = 0;
	Node *node = ll->head;
	while (i < index)
	{
		node = node->next;
		i++;
	}
	return node->data;
}

void sort(List *ll) {
	if (!ll) 
	{
		return;
	}
	if(ll->size == 0)
	{
		return;
	}
   char* t_key;
   char* t_data;
   int i, j, k;
   struct Node *cur=(Node *)malloc(sizeof(Node));
   struct Node *next_node=(Node *)malloc(sizeof(Node));
   t_data=malloc(sizeof(char *)*1024);
   t_key=malloc(sizeof(char *)*1024);
   int the_size = ll->size;
   k = the_size ;
	
   for ( i = 0 ; i < the_size - 1 ; i++, k-- ) {
      cur = ll->head;
      next_node = ll->head->next;
		
      for ( j = 1 ; j < k ; j++ ) {   

         if ( cur->data->value > next_node->data->value ) {
			strcpy(t_data,cur->data->value);
			strcpy(cur->data->value , next_node->data->value);
			strcpy(next_node->data->value,t_data);
			strcpy(t_key,cur->data->value);
			strcpy(cur->data->value,next_node->data->value);
			strcpy(next_node->data->value , t_key);
         }
			
         cur = cur->next;
         next_node = next_node->next;
      }
   }   
}

void printList(List *ll) 
{
	if (!ll) 
	{
		return;
	}
	if(ll->size == 0)
	{
		return;
	}
   struct Node *ptr = ll->head;
   printf("\n[ ");
	
   while(ptr != NULL) {
      printf("(%s,%s) ",ptr->data->key,ptr->data->value);
      ptr = ptr->next;
   }
	
   printf(" ]");
}

void add(List *ll, void *data){
if (!ll)
	{
		return;
	}
	Node *node = (Node *)malloc(sizeof(Node));
	node->next = NULL;
	node->prev = ll->tail;
	node->data = data;
	ll->size++;
	if (!ll->head)
	{
		ll->head = ll->tail = node;
		return;
	}

	ll->tail->next = node;
	ll->tail = node;
}
