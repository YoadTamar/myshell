#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "stdio.h"
#include "errno.h"
#include "stdlib.h"
#include "unistd.h"
#include <string.h>
#include <signal.h>
#include "linkedlist.h"
#include <termios.h>   
#include <unistd.h>  

#define PIPE "|"
#define AMPER "&"
#define REDIRECT ">"
#define DOUBLE_REDIRECT ">>"
#define ERROR "2>"
#define INPUT "<"
#define PROMPT "prompt"
#define EQUAL "="
#define PRINT "echo"
#define LAST_EXIT_CODE "$?"
#define DOLLAR '$'
#define CD "cd"
#define REPEAT_LAST_COMMAND "!!"
#define READ "read"
#define EXIT_CODE "quit"

char command[1024],lastCommand[1024], currentCommand[1024],prompt[1024];
int last_command,fd, amper, rv ,piping , i;
int DuplicateFD, mainProcess,status = 0;
int change_status(char **args);
char current_command[1024]; 
List variables,commands;
char **CountPIPEPointer; 
pid_t ProccesID,cpid;
char* end_if="fi\n";
char *new_command2;
char *new_command;
char *argv[1024];
char *outfile;
int pipeFD[2]; 
char *token;
int enter=0;
char a,b,c;


/**
 * Finds the first occurrence of the PIPE string in the array of strings (args).
 * 
 * Args:
 *     args (char **): Array of strings representing command-line arguments.
 * 
 * Returns:
 *     char **: A pointer to the first occurrence of the PIPE string in the array.
 *              Returns NULL if the PIPE string is not found.
 */
char **how_much_pipe(char **);


/**
 * Counts the number of arguments in the array of strings (args).
 * 
 * Args:
 *     args (char **): Array of strings representing command-line arguments.
 * 
 * Returns:
 *     int: The total number of arguments in the array.
 */
int how_much_args(char **);


/**
 * Copies the contents of the source string (s) to the destination string (d)
 * up to the specified size, ensuring null-termination.
 * 
 * Args:
 *     d (char *): Destination string where the content is copied.
 *     size (size_t): Maximum number of characters to copy, including the null terminator.
 *     s (char *): Source string to be copied.
 * 
 * Returns:
 *     char *: A pointer to the destination string (d).
 */
char *my_strcpy(char *, size_t , char *);


/**
 * Finds the index of the first non-null element in the given character array.
 * 
 * Args:
 *     array (char*): The input character array.
 * 
 * Returns:
 *     int: The index of the first non-null element in the array.
 */
int find_first_element(char*);


/**
 * Splits a command string into separate arguments using space as the delimiter.
 * 
 * Args:
 *     command (char*): The input command string to be split.
 * 
 * Note:
 *     Assumes a global or externally declared array 'char* argv[MAX_ARGS]' to store the split arguments.
 *     The last element of the 'argv' array is set to NULL.
 */
void split(char *);


/**
 * Signal handler for handling the Control-C signal (SIGINT).
 * 
 * Args:
 *     signum (int): The signal number received.
 * 
 * Note:
 *     Assumes the existence of global variables:
 *         - int mainProcess: Process ID of the main process.
 *         - char* prompt: Prompt string to be displayed after handling the signal.
 */
void handle_signal(int);


/**
 * Executes a command represented by an array of strings (args).
 * 
 * Args:
 *     args (char**): An array of strings representing the command and its arguments.
 * 
 * Returns:
 *     int: The exit status of the executed command.
 * 
 * Notes:
 *     - Assumes the existence of global or externally declared variables like:
 *         - int pipes: Counter for the number of pipes encountered in the command.
 *         - int mainProcess: Process ID of the main process.
 *         - char* prompt: Prompt string used in the shell.
 *         - char lastCommand[]: Buffer to store the last executed command.
 *         - int status: Exit status of the last executed command.
 *         - VarList variables: A linked list for storing variables.
 *     - Supports input/output redirection and background execution.
 *     - Handles piping between commands.
 *     - Implements built-in commands such as 'cd', 'echo', 'read', and variable assignments.
 *     - Utilizes a history feature to execute the last command with '!!'.
 *     - Note: Some global variables like 'pipeFD', 'DuplicateFD', 'ProccesID', and 'rv' are assumed to be declared elsewhere.
 */
int execute(char **);

/**
 * Executes a command represented by an array of strings (args) and updates the exit status.
 * 
 * Args:
 *     args (char**): An array of strings representing the command and its arguments.
 * 
 * Returns:
 *     int: The exit status of the executed command.
 * 
 * Notes:
 *     - If no command is provided (args[0] is NULL), sets the exit status to 0.
 *     - Calls the execute function to handle command execution and updates the exit status.
 */
int change_status(char **);

