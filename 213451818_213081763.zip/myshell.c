#include "myshell.h"

char **how_much_pipe(char **args)
{
    char **pipe_count = args;
    while (*pipe_count != NULL)
    {
        if (strcmp(*pipe_count, PIPE) == 0)
        {
            return pipe_count;
        }

        pipe_count++;
    }
    return NULL;
}

int how_much_args(char **args)
{
    char **args_count = args;
    int count = 0;
    while (*args_count != NULL)
    {
        args_count++;
        count++;
    }
    return count;
}


char *my_strcpy(char *dest, size_t size, char *src) 
{
    if (size > 0) {
        *dest = '\0';
        return strncat(dest, src, size - 1);
    }
    return dest;
}

int find_first_element(char* array){
    int index;
        for (index= 0; i < 1024; i++) {
        if (strlen(array) <= i) {
            break;
        }
    }
    return index;
}

void split(char *command)
{
    char *part_of_command = strtok(command, " ");
    int i = 0;
    while (part_of_command != NULL)
    {
        argv[i] = part_of_command;
        part_of_command = strtok(NULL, " ");
        i++;
    }
    argv[i] = NULL;
}

void handle_signal(int signum)
{ 
    if (getpid() == mainProcess) {
        printf("\n");
        printf("You typed Control-C!");
        printf("\n");
        char p[1026] = {'\0'};
        int kkk = 0;
        for(;kkk < strlen(prompt); kkk++)
        {
            p[kkk] = prompt[kkk];
        }
        p[kkk+1] = ':';
        p[kkk + 2] = ' ';
        write(0, p , strlen(prompt)+3);
        return;
    }
    else{
        fprintf(stderr, "\ncaught signal: %d\n", signum);
        kill(mainProcess, SIGKILL);
        return;
    }
}

int execute(char **args)
{
    rv = -1; piping  = 0; i = how_much_args(args); char **CountPIPEPointer = how_much_pipe(args); 
    if (CountPIPEPointer != NULL)
    {
        *CountPIPEPointer = NULL;
        piping++;
        int result=pipe(pipeFD);
        if (result == -1) {
        printf("Failed to create pipe\n");
        exit(EXIT_FAILURE);
        }

        cpid = fork();

        if (cpid == -1)
        {       
            perror("Error occurred: Failed to create new process\n");
            exit(EXIT_FAILURE);
        }

        else if (cpid == 0)
        {
            int status =close(pipeFD[1]); 
            if (status == -1) {
            printf("Failed to close file descriptor\n");
            exit(EXIT_FAILURE);
            } 

            int status_file =close(0);
            if (status_file == -1) {
            printf("Failed to close standard input file descriptor\n");
            exit(EXIT_FAILURE);
            }

            int newFD =dup(pipeFD[0]); 
            if (newFD == -1) 
            {
            printf("Failed to duplicate file descriptor\n");
            exit(EXIT_FAILURE);
            } 
            execute(CountPIPEPointer + 1);
            exit(0);
        }

        DuplicateFD = dup(STDOUT_FILENO); 
        if (DuplicateFD == -1) {
            printf("Failed to duplicate file descriptor\n");
            exit(EXIT_FAILURE);
        }
        dup2(pipeFD[1], STDOUT_FILENO);

    }

    if (args[0] == NULL)
        return 0;

    if (!strcmp(args[i - 1], AMPER))
    {
        amper = 1;
        args[i - 1] = NULL;
    
    }

    int redirect = -1;
    if (i >= 2 && (!strcmp(argv[i - 2], REDIRECT) || !strcmp(argv[i - 2], DOUBLE_REDIRECT)))
    {
        outfile = argv[i - 1];
        redirect = 1;
    }
    else if (i >= 2 && !strcmp(argv[i - 2], ERROR))
    {
        outfile = argv[i - 1];
        redirect = 2;
    }
    else if (i >= 2 && !strcmp(argv[i - 2], INPUT))
    {
        outfile = argv[i - 1];
        redirect = 0;
    }

    if (strcmp(args[0], PROMPT)==0)
    {
         if (!strcmp(argv[1], EQUAL))
             {
                strcpy(prompt, args[2]);
            }

        return 0;
    }
        if (strcmp(args[0], PRINT)==0)
    {
        char **echo_var = args + 1;
        if (strcmp(*echo_var, LAST_EXIT_CODE)==0)
        {
            printf("%d\n", status);
            return 0;
        }

        while (*echo_var)
        {
            
            if (echo_var != NULL && echo_var[0][0] == DOLLAR)
            {
                Node *node = variables.head;
                char *new_variable = NULL;

                while (node)
                {
                    if (strncmp(((Var *)node->data)->key, *echo_var, strlen(*echo_var)) == 0)
                    {
                        new_variable=((Var *)node->data)->value;
                    }
                    node = node->next;
                }
                if (new_variable != NULL)
                    printf("%s ", new_variable);
            }

            else{
            printf("%s ", echo_var[0]);
            }

            echo_var++;
        }
        printf("\n");
        return 0;
    }

    else
        amper = 0;
    if (strcmp(args[0], CD)==0)
    {
        if (chdir(args[1]) != 0){
        printf(" %s: no such directory\n", argv[1]);
    
    }
        return 0;
    }

    if (strcmp(args[0], REPEAT_LAST_COMMAND)==0)
    {
        if(commands.size>0){
        strcpy(currentCommand, lastCommand);
        split(currentCommand);
        execute(argv);
        }
        else{
            printf("The command history list is empty");
        }

        return 0;
    }
    
    if (args[0][0] == '$' && i > 2)
    {
        Var *var = (Var *)malloc(sizeof(Var));
        var->key = malloc((strlen(args[0]) + 1));
        var->value = malloc((strlen(args[2]) + 1));
        strcpy(var->key, args[0]);
        strcpy(var->value, args[2]);
        add(&variables, var);
        return 0;
    }
    if(strcmp(args[0], READ)==0)
    {
        Var *var = (Var *)malloc(sizeof(Var));
        var->key = malloc(sizeof(char) * (strlen(args[1])));
        var->value = malloc(sizeof(char) * 1024);
        var->key[0] = '$';
        memset(var->value, 0, 1024);
        strcpy(var->key + 1, args[1]);
        fgets(var->value, 1024, stdin);

        var->value[strlen(var->value) -1] = '\0';
        add(&variables, var);
        return 0;
    }

    ProccesID = fork();

    if (ProccesID == 0)
    {
        if (redirect >= 0)
        {
            if (!strcmp(args[i - 2], DOUBLE_REDIRECT))
            {
                if ((fd = open(outfile, O_APPEND | O_CREAT | O_WRONLY, 0660)) < 0)
                {
                    perror("Error: Can't create file");
                    exit(1);
                }
                lseek(fd, 0, SEEK_END);
            }
            else if (!strcmp(args[i - 2], REDIRECT) || !strcmp(args[i - 2], ERROR))
            {
                if((fd = creat(outfile, 0660))<0){
                    perror("Error: Can't create file");
                    exit(1);
                }
             
            }
            else
            {
                fd = open(outfile, O_RDONLY);
            }
            close(redirect);
            dup(fd); 
            close(fd);
            args[i - 2] = NULL;
        }
        int status_code=execvp(args[0], args);
        if (status_code == -1) {
                printf("Unknown command: %s\n", command);
                exit(1);
            }
    }
    else if (ProccesID == -1) {
            printf("Error forking a new process\n");
            exit(1);
        }
    else {
 
        ProccesID = -1;

        wait(&status); 
        rv = status;  
    }

    if (piping !=0 )
    {

        int status = close(STDOUT_FILENO);

        if (status == -1) {
            printf("Failed to close standard output file descriptor\n");
            exit(EXIT_FAILURE);
        } 

        int newFD =dup(DuplicateFD);
        if (newFD == -1) {
            printf("Failed to duplicate file descriptor\n");
            exit(EXIT_FAILURE);
        } 

        int status_pipeFD =close(pipeFD[1]);
            if (status_pipeFD == -1) {
            printf("Failed to close file descriptor\n");
            exit(EXIT_FAILURE);
        } 

        wait(NULL);
    }

    return rv;
}

int change_status(char **args)
{
    int rv = -1;
    if (args[0] == NULL)
    {
        rv = 0;
        return rv;
    }
    else 
    {
        rv = execute(args);
        return rv;
    }
}


int main()
{
    mainProcess = getpid(); 
    signal(SIGINT, handle_signal); 
    strcpy(prompt, "hello");
    last_command=0;
    char* prevCommand=malloc(sizeof(char) * 1024);
    struct termios old_terminal, new_terminal;
    tcgetattr(STDIN_FILENO, &old_terminal);

    while (1)
    {
        memset(command, 0, sizeof(command));
        new_terminal = old_terminal;
        new_terminal.c_lflag &= ( ECHOE | ~ICANON);
        tcsetattr(STDIN_FILENO, TCSANOW, &new_terminal);

        printf("\r");
        printf("%s: ", prompt);
        i=1;

        c=getchar();
        
        if (c == '\n')
        {
        tcsetattr(STDIN_FILENO, TCSANOW, &old_terminal);

        if(commands.size>0){ 
        prevCommand=(char *)get_command(&commands, last_command);
        new_command2= malloc(sizeof(char) * strlen(prevCommand));
        prevCommand[strlen(prevCommand)]=' ';
        strcpy(new_command2, prevCommand);
        add(&commands, new_command2);

        last_command = commands.size;

        strcpy(command, new_command2);
        split(command);

        status = change_status(argv);
        }
        continue;
        }

        else
        {

        tcsetattr(STDIN_FILENO, TCSANOW, &old_terminal);
        memset(command, 0, 1024);
        command[0]=c;
        char b;
        int Flag=0;
        i=1;
        
        while((b = getchar()) != '\n')
        {  
            if(b == 127 || b=='\b')
            {
                printf("\b \b");
                i--;
                           
            }
            else 
            {
                command[i] = b; i++;
            };
               
        }
        command[i] = b;
        i++;
        command[strlen(command)]='\0';
        i=1;
        }


    int if_flag=0;
    if (!strncmp(command, "if", 2)) {
        if_flag=1;
        while (1) {
            fgets(current_command, 1024, stdin);
            strcat(command, current_command);
            command[strlen(command) - 1] = '\n';
            if (!strcmp(current_command, end_if))
                break;
        }
        char* commandcurr = "bash";
        char* argument_list[] = {"bash", "-c", command, NULL};
        if (fork() == 0) {
            int status_code = execvp(commandcurr, argument_list);
            printf("bash has taken control of this child process. This won't execute unless it terminates abnormally!\n");
            if (status_code == -1) {
                printf("Terminated Incorrectly\n");
                return 1;
            }
        }
            wait(&status);
            strcat(command, current_command);
        }
        command[strlen(command) - 1] = '\0';

        if (!strcmp(command, EXIT_CODE)){
            exit(0);
        }
        
        if (strcmp(command, REPEAT_LAST_COMMAND)){
            tcsetattr(STDIN_FILENO, TCSANOW, &old_terminal);
            strcpy(lastCommand, command);
        }
        

        new_command= malloc(sizeof(char)*strlen(command));
        strcpy(new_command, command);
        add(&commands, new_command);
        last_command = commands.size;

        if(!if_flag){
        split(command);
        status = change_status(argv);
        }
        else{
            continue;
        }
        
        }
    }